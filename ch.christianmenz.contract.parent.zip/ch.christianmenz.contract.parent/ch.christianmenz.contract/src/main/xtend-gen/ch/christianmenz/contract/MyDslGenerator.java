package ch.christianmenz.contract;

import ch.christianmenz.contract.mafDsl.Contract;
import ch.christianmenz.contract.mafDsl.Method;
import com.google.common.collect.Iterators;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

/**
 * Generates code from your model files on save.
 * 
 * See https://www.eclipse.org/Xtext/documentation/303_runtime_concepts.html#code-generation
 */
@SuppressWarnings("all")
public class MyDslGenerator extends AbstractGenerator {
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Contract _get = IteratorExtensions.<Contract>toList(Iterators.<Contract>filter(resource.getAllContents(), Contract.class)).get(0);
    final Contract contract = ((Contract) _get);
    fsa.generateFile("test.groovy", this.generateCppCode(contract));
  }

  public CharSequence generateCppCode(final Contract e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("#ifndef __MYSTRUCT_H_");
    _builder.newLine();
    _builder.append("#define __MYSTRUCT_H_");
    _builder.newLine();
    _builder.append("#include <cstdint>");
    _builder.newLine();
    _builder.newLine();
    _builder.append("struct MyStruct {");
    _builder.newLine();
    _builder.append("\t");
    Method _method = e.getMethod();
    _builder.append(_method, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t   ");
    _builder.append("float attribute1;");
    _builder.newLine();
    _builder.append("\t   ");
    _builder.append("int32_t attribute2;");
    _builder.newLine();
    _builder.append("};");
    _builder.newLine();
    _builder.newLine();
    _builder.append("#endif");
    _builder.newLine();
    return _builder;
  }
}
