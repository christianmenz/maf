package ch.christianmenz.contract;

import java.io.IOException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.xtext.generator.IGenerator;
import org.eclipse.xtext.generator.IGenerator2;
import org.eclipse.xtext.generator.InMemoryFileSystemAccess;

import com.google.inject.Injector;

public class Main {
	
	public static void main(String[] args) throws IOException {
		Injector injector = new MafDslStandaloneSetup().createInjectorAndDoEMFRegistration();

		ResourceSet resourceSet = injector.getInstance(ResourceSet.class);
		URI createFileURI = URI.createURI("contract.maf");
		Resource r = resourceSet.getResource(createFileURI, true);
		r.load(null);
		
		IGenerator2 generator = injector.getInstance(MyDslGenerator.class);
		InMemoryFileSystemAccess fsa = injector.getInstance(InMemoryFileSystemAccess.class);
		generator.doGenerate(r, fsa, null);
		for (CharSequence s : fsa.getTextFiles().values()) {
			System.out.println(s);
		}
		
	}

}
